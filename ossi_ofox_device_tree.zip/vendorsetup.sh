#
# Copyright (C) 2026 The Android Open Source Project
#
# SPDX-License-Identifier: Apache-2.0
#

add_lunch_combo twrp_ossi-eng
add_lunch_combo twrp_ossi-userdebug
add_lunch_combo twrp_ossi-user
